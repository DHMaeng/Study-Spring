package mc.sn.maeng.member.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component("memberVO")
public class MemberVO {
	private String id;
	private String password;
	private String username;

	public MemberVO() {		
	}
	
	public MemberVO(String id, String pwd, String name) {
		this.id = id;
		this.password = pwd;
		this.username = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return password;
	}

	public void setPwd(String pwd) {
		this.password = pwd;
	}

	public String getName() {
		return username;
	}

	public void setName(String name) {
		this.username = name;
	}
	
	@Override
	public String toString() {
		String info = id+", "+ password+", "+ username;
		return info;
	}

}
