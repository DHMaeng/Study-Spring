package mc.sn.maeng.member.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import mc.sn.maeng.member.vo.MemberVO;


public interface MemberService {

	 public MemberVO login(MemberVO memberVO) throws Exception;
}
