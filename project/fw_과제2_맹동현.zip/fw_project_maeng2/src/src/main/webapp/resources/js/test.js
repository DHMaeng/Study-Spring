/**
 * 
 */
window.onload = function() {
	//var flag = false;
	//alert('welcome');연결됐는지 확인
	var button = document.getElementById('login_btn');
	
	button.onclick = function() {
		var userId = document.getElementById('id').value;
		var pwd = document.getElementById('pw').value;

		alert(userId + "," + pwd);
	};
};