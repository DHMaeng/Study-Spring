package mc.sn.maeng.member.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import mc.sn.maeng.member.vo.MemberVO;

public interface MemberDAO {

	 public MemberVO loginById(MemberVO memberVO) throws DataAccessException;

}
