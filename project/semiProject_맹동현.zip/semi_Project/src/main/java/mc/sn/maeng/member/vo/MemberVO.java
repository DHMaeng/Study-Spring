package mc.sn.maeng.member.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component("memberVO")
public class MemberVO {
	private String top;
	private String bottom;
	private String shoes;

	public MemberVO() {		
	}
	
	public MemberVO(String top, String bottom, String shoes) {
		this.top = top;
		this.bottom = bottom;
		this.shoes = shoes;
	}
	
	public String getTop() {
		return top;
	}

	public void setTop(String top) {
		this.top = top;
	}

	public String getBottom() {
		return bottom;
	}

	public void setBottom(String bottom) {
		this.bottom = bottom;
	}

	public String getShoes() {
		return shoes;
	}

	public void setShoes(String shoes) {
		this.shoes = shoes;
	}

	@Override
	public String toString() {
		String info = top+", "+ bottom+", "+ shoes;
		return info;
	}

}
