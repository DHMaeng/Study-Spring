package mc.sn.basic.ai.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import mc.sn.basic.ai.service.AIService;




@Controller("aiController")
public class AIControllerImpl   implements AIController {
	@Autowired
	private AIService aiService;
	
	@Override
	@RequestMapping(value="/nmt1" ,method = RequestMethod.GET)
	@ResponseBody
	public String nmt(@RequestParam("words") String words, HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		 request.setCharacterEncoding("utf-8");
		 System.out.println("aiController "+words);
		 String result = null;
		 result = aiService.translate(words);		
	
		return result;
	}
}
